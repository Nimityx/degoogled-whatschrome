# degoogled-whatschrome
Whatschrome chromeapp without google analytics

Fork of [whatsapp-chrome](https://github.com/julman99/whatsapp-chrome) [version 0.8.0](https://robwu.nl/crxviewer/?crx=https%3A%2F%2Fchrome.google.com%2Fwebstore%2Fdetail%2Fwhatschrome%2Fbgkodfmeijboinjdegggmkbkjfiagaan) but without the trackers and annoyances

[Download CRX](https://raw.githubusercontent.com/Nimityx/degoogled-whatschrome/main/degoogled-whatschrome-0.8.0.crx)

[Download ZIP](https://raw.githubusercontent.com/Nimityx/degoogled-whatschrome/main/degoogled-whatschrome-0.8.0.zip)